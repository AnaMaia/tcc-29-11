<?php


class TipoProduto

{
    public $idTipoProduto = null;
    public $tipo;

    function __construct($tipo, $idTipoProduto = null)
    {
        $this->tipo = $tipo;
        $this->idTipoProduto = $idTipoProduto;
    }
}