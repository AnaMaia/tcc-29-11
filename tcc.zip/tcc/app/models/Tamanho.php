<?php


class Tamanho

{
    public $idTamanho = null;
    public $tamanho;

    function __construct($tamanho, $idTamanho = null)
    {
        $this->tamanho = $tamanho;
        $this->idTamanho = $idTamanho;
    }
}