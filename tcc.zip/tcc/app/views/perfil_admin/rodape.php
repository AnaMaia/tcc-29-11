<?php
@session_start();
$base_url = "http://localhost/tcc";
?>


<script src="<?= $base_url ?>/assets/js/jquery-1.10.2.js"></script>
<!-- BOOTSTRAP SCRIPTS -->
<script src="<?= $base_url ?>/assets/js/bootstrap.min.js"></script>
<!-- METISMENU SCRIPTS -->
<script src="<?= $base_url ?>/assets/js/jquery.metisMenu.js"></script>
<!-- MORRIS CHART SCRIPTS -->
<script src="<?= $base_url ?>/assets/js/morris/raphael-2.1.0.min.js"></script>
<script src="<?= $base_url ?>/assets/js/morris/morris.js"></script>
<!-- CUSTOM SCRIPTS -->
<script src="<?= $base_url ?>/assets/js/custom.js"></script>



</body>
</html>